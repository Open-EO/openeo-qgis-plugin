from enum import Enum

class SettingsPath(Enum):
    SAVED_CONNECTIONS = "openeo_plugin/saved_connections"
    SAVED_LOGINS = "openeo_plugin/saved_logins"